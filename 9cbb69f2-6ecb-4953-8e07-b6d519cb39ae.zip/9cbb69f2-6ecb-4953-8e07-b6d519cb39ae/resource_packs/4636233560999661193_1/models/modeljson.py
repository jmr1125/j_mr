# -*- coding: utf-8 -*-
# 拷贝到vanilla_netease/models下运行

import os
import json
for root, _, files in os.walk('.'):
	for file in files:
		if file.endswith('.json') and file != 'netease_models.json':
			with open(os.path.join(root, file), 'r') as f:
				d = json.load(f)
			with open(os.path.join(root, file), 'w') as f:
				json.dump(d, f)